import os


_base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
