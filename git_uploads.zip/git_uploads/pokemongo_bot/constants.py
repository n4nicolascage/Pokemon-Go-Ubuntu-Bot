class Constants(object):
  MAX_DISTANCE_FORT_IS_REACHABLE = 40 # meters
